function r = mtimes(A,x)
r = A.func(x);