First-order Augmented Lagrangian (FAL) algorithm for basis pursuit

 Solves

   min ||x||_1 s.t. Ax=b

 Inputs
 
 A - an explicit m x n matrix, or a function handle that implements 
     A*x and A'*x.  If the latter is given, this function must have the form

     function y = name(x,mode)

     where if mode == 1 then x is n x 1 and y = A*x, and if mode == 2 then 
     x is m x 1 and y = A'*x.

 b - an m x 1 vector.


 fal_opts.m describes the available options.  If opts is passed as empty,
 fal_opts will be called to obtain the default values.

 Outputs

%   x           - x at last iteration
%   out.lambda  - vector of lambda values for each outer iteration
%   out.l1      - vector of ||x||_1
%   out.res     - vector of residual norm values: ||Ax-b||_2
%   out.rel     - if opts.xs exists, is vector of norm(x - xs)/norm(xs).
%                 starts with 0th iteration.
%   out.oitr    - number of FAL iterations to convergence
%   out.itr     - number of inner iterations to convergence (or Inf if reach mxitr)
%   out.itrs    - vector of number of inner iterations completed during each
%                 outer iteration
%   out.nmat    - number of matrix multiplications with A and A'
%
% Written by Necdet Serhat Aybat, Penn State University