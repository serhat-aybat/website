function x_shrunk = shrinkage_l1(y,delta)
n = size(y,1);
sign_y = sign(y);
c = max(abs(y)-delta*ones(n,1),zeros(n,1));
x_shrunk = sign_y .* c;