function [batch_mode, test_type, data_flag, stopping_type, Excel, File] = initialize(batch_mode, test_type, data_flag, rand_flag, stopping_type, Excel, File)
% test_type= 0 nothing, 1 selftests and 2 comparative tests are saved.

%stopping_time =  
%   1: function value change is observed as stopping cond.
%   2: infty norm difference of consecutive iterates is observed
%   0: infty norm difference of current iterate and x* is observed


if isempty(batch_mode)
    batch_mode = 0;
    test_type = 0;
    if isempty(data_flag)
        data_flag = 0;
    end
    if isempty(stopping_type)
        stopping_type = 0;
    end
    if isempty(rand_flag)
        rand_flag = 1;
    end
    if rand_flag == 1
        seed = 601;
        randn('state',seed); rand('state',seed);
    end
    Excel = []; File= [];
else
    if isempty(data_flag)
        data_flag = 0;
    end
    if (test_type == 1)||(test_type == 0)
        if isempty(stopping_type)
            stopping_type = 0;
        end
    elseif test_type == 2
        if isempty(stopping_type)
            stopping_type = 2;
        end
    end
end