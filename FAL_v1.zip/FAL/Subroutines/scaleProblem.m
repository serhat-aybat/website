function [A,b,scale_constant] = scaleProblem(n,A,b,kappa,flag)

% Scales lambda, A and b so that the largest singular value of A is 1 and the
% new problem
%
%       min lambda ||x||_1 + 1/2 ||Ax - b-lambda theta||_2^2
%
% is equivalent to the old one.  We assume that A is a function handle
% that take the arguments (x,mode), and return, A*x if mode == 1 and A'*x if mode == 2.
if isa(A,'function_handle')
    if kappa>0
        b = b/kappa;
        A = @(x,mode) A(x,mode)/kappa;
        scale_constant = kappa;
    else
        scale_constant = 1;
        eopts.disp = 0;
        eopts.issym = true;
        if ~isreal(A(rand(n,1),1))
            eopts.isreal = false;
        end

        fh = @(x) A(A(x,1),2);
        s2 = eigs(fh,n,1,'lm',eopts);
        if s2 > 1 - eps
            b = b/sqrt(s2);
            A = @(x,mode) A(x,mode)/sqrt(s2);
            scale_constant = sqrt(s2);
        end
    end
else
    if flag == 0
        if kappa>0
            b = b/kappa;
            A = A/kappa;
            scale_constant = kappa;
        else
            scale_constant = 1;
            eopts.disp = 0;
            eopts.issym = true;
            if ~isreal(A*rand(n,1))
                eopts.isreal = false;
            end

            fh = @(x) A'*(A*x);
            s2 = eigs(fh,n,1,'lm',eopts);
            if s2 > 1 - eps
                b = b/sqrt(s2);
                A = A/sqrt(s2);
                scale_constant = sqrt(s2);
            end
        end
    else
        scale_constant = 1; %This is not correct...
        [Q,R]=qr(A',0);
        A=Q';
        b=inv(R')*b;
    end
end

return