function [coef_lambda, coef_tau, stepsize] = set_coefficients(nzr)
if nzr>=0.9
    coef_lambda = 0.9;
    stepsize = 1.8;
elseif (nzr >= 0.6)&&(nzr < 0.9)
    coef_lambda = 0.85;
    stepsize = 1.85;
elseif (nzr >= 0.25)&&(nzr < 0.6)
    coef_lambda = 0.8;
    stepsize = 1.9;
elseif (nzr >= 0.1)&&(nzr < 0.25)
    coef_lambda = 0.6;
    stepsize = 2;
else
    coef_lambda = 0.4;
    stepsize = 3;
end
coef_tau = coef_lambda-0.01;

%Use below code to test static coefficient scheme for data_flag=1,2
%coef_lambda=0.4; coef_tau=0.4; stepsize=4;
%Use below code to test static coefficient scheme for data_flag=3
%coef_lambda=0.6; coef_tau=0.6; stepsize=1.4;