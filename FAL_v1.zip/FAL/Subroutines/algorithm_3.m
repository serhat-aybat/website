function [y, tau, iter_counter, operation_counter] = algorithm_3(x0,A,b_prime,lambda,beta,tau,stepsize,Ay,N,b,opts)

global L c0 coef_tau nz nrm_xopt
global outer_iter_counter inner_iter_counter total_operation_counter total_time optimality_flag

partial_grad_sum = 0;
L_prime = L/stepsize;
k=0; theta = 1;
x = x0; y=x0;
treshold = max(1e-11,3*opts.sigma); operation_counter = 1; fmean = [];

flag = 1;
while(flag)
    r_y = Ay-b_prime;
    grad_f = A'*r_y;
    operation_counter = operation_counter + 1;
    
    ind_non0 = abs(y)>treshold;
    ind_0 = abs(y)<=treshold;
    norm_grad_P = norm((grad_f+lambda*sign(y)).*ind_non0+(max(abs(grad_f)-lambda*ones(N,1),zeros(N,1))).*ind_0);
    partial_grad_sum = partial_grad_sum + grad_f/theta;
     
    if opts.stop == 0
        opt_check_value = opts.xopt;
    elseif opts.stop == 1 || opts.stop == 2
        opt_check_value = x;
    elseif opts.stop == 2
        p_y = norm(y,1);
        if k==0
            pmean = p_y;
            opt_check_value = inf;
        else
            opt_check_value = abs(p_y - mean(pmean))/mean(pmean);
            pmean = [p_y,pmean];
            if (length(pmean) > 5) 
                pmean = pmean(1:5);
            end
        end
    end
    
    [z, shrink_flag] = constrained_shrinkage_l1(x0-partial_grad_sum/L_prime,lambda/(L_prime*theta^2),beta);
    [x, shrink_flag] = constrained_shrinkage_l1(y-grad_f/L_prime,lambda/L_prime,beta);
    %*********************************************************************
    if opts.disp == 2
        if isempty(opts.xopt)
            rel_err_sol = norm(x-opt_check_value,2)/nrm_xopt;
            disp(['Inner Iteration no: ',num2str(inner_iter_counter+k+1),' --> |x-x*|_2/|x*|_2=', num2str(rel_err_sol)])
        else
            rel_err_sol = norm(x-opt_check_value,2)/(1+norm(opt_check_value,2));
            disp(['Inner Iteration no: ',num2str(inner_iter_counter+k+1),' --> |x-xp|_2/(1+|xp|_2)=', num2str(rel_err_sol)])
        end
    end
    %*********************************************************************
 
    theta =(sqrt(theta^4+4*theta^2)-theta^2)/2;
    
    %***********************
    y = (1-theta)*x+theta*z;
    %***********************
    
    if k==0
        tau = min(coef_tau*tau, norm_grad_P*c0);
    end
    
    k = k+1;
    
    if optimality_check(opts.tol, x, opt_check_value, opts.stop, opts.sigma) || shrink_flag
        total_time = toc;
        beep
        if shrink_flag
            optimality_flag = 0;
            disp(' ')
            disp('********************************************************')
            disp(['FAL is early terminated, choose a value for opts.tol larger than ',num2str(opts.tol)])
            disp('********************************************************')
            break;
        else
            optimality_flag = 0;
            o1 = norm(x,1);
            o2 = norm(A*x-b,2);
            nnz = sum(abs(x)>max(0,treshold));
            out.oitr = outer_iter_counter;
            out.itr = inner_iter_counter+k;
            out.nmat= total_operation_counter+operation_counter;

            disp(' ')
            disp('********************************************************')
            disp('*                 SOLUTION SUMMARY                     *')
            disp('********************************************************')
            display(['Total Time: ',num2str(total_time),' sec.'])        
            display([num2str(out.oitr),' outer iterations done.'])
            display([num2str(out.itr),' inner iterations done.'])
            display([num2str(out.nmat),' matrix multiplications done.'])
            display(['L1 Norm: ', num2str(o1), '  |Ax-b|_2: ', num2str(o2)])
            display(['x has ',num2str(nnz),' nonzero components'])

            if ~isempty(opts.xopt)
                l1_opt = norm(opts.xopt,1);
                rel_err_l1 = abs(l1_opt-o1)/l1_opt;
                rel_err_sol = norm(x-opts.xopt)/nrm_xopt;
                ind_x = find(abs(opts.xopt)>0);
                ind_0 = find(opts.xopt==0);
                inf_err_x = norm(x(ind_x)-opts.xopt(ind_x),inf);
                inf_err_0 = norm(x(ind_0)-opts.xopt(ind_0),inf);
                display(['L1 Norm(x*): ',num2str(l1_opt),'  |x-x*|_2/|x*|_2: ',num2str(rel_err_sol),'  ||x|_1-|x*|_1|/|x*|_1: ',num2str(rel_err_l1)]);
                display(['max{|x_i-x*_i|: |x*_i|>0}: ',num2str(inf_err_x)])
                display(['max{|x_i|: x*_i=0}: ',num2str(inf_err_0)])
            end             
            break;
        end
    end
    
    if (norm_grad_P <= tau)
        
        nz=[nz, sum(abs(x)>treshold)];
        
        %*********************************************************************
        if opts.disp == 1 || opts.disp == 2
            if isempty(opts.xopt)
                rel_err_sol = norm(x-opt_check_value,2)/nrm_xopt;
                disp(['FAL Iteration no: ',num2str(outer_iter_counter),' --> |x-x*|_2/|x*|_2=', num2str(rel_err_sol)])
            else
                rel_err_sol = norm(x-opt_check_value,2)/(1+norm(opt_check_value,2));
                disp(['FAL Iteration no: ',num2str(outer_iter_counter),' --> |x-xp|_2/(1+|xp|_2)=', num2str(rel_err_sol)])
            end
        end
        %*********************************************************************
        break;
    end
    Ay = A*y;
    operation_counter = operation_counter + 1;
end
iter_counter = k;
if (opts.disp == 1 || opts.disp == 2)&&optimality_flag
    display(['     ',num2str(iter_counter),' inner iterations --> ', num2str(operation_counter),' matrix multiplications.'])
end