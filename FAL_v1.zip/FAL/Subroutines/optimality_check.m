function val = optimality_check(opt_tol, x, opt_check_value, stopping_type, sigma)
val = 0;
if (stopping_type == 0)||(stopping_type == 1)
    if norm(x-opt_check_value,inf) <= opt_tol
        val = 1;
    end
elseif stopping_type == 2 && norm(opt_check_value,inf)>0
    if norm(x-opt_check_value)/norm(opt_check_value) <= opt_tol*sigma
        val = 1;
    end
elseif stopping_type == 3
    if opt_check_value <= opt_tol
        val = 1;
    end
elseif stopping_type == 4 && norm(opt_check_value,inf)>0
    if norm(x-opt_check_value)/norm(opt_check_value) <= opt_tol
        val = 1;
    end
end