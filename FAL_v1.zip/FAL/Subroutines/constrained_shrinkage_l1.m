function [x_shrunk, shrink_flag] = constrained_shrinkage_l1(y,delta,sigma)
shrink_flag = 0;
n = size(y,1);
sign_y = sign(y);
c = max(abs(y)-delta,0);
if sum(c) > sigma+1e-3
    %display('Beta Constraint is binding!!!!')
    sorted_c = sort(c,'descend');
    max_i = 0;
    partial_sum = 0;
    final_sum = 0;
    for i=1:n
        partial_sum = partial_sum + sorted_c(i);
        dummy = sorted_c(i)-(partial_sum-sigma)/i;
        if dummy <= 0
            max_i=i-1;
            final_sum=partial_sum-sorted_c(i);
            break
        end
    end
    if dummy>0
        max_i = n;
        final_sum = partial_sum;
    end
    theta=(final_sum-sigma)/max_i;
    x_shrunk = max(c-theta*ones(n,1),zeros(n,1));
    x_shrunk = x_shrunk .*sign_y;
    shrink_flag = 1;
else
    x_shrunk = sign_y .* c;
end