% N: signal length
% K: number of observations to make
% T: number of spikes in the signal
% L: Lipschitz constant of 1/2*||Ax-b||_2^2, which is (sigma_max(A))^2
% data:
%       0: x* is random signal with 100dB dynamic range, partial DCT A and
%          b=Ax*+eta
%       1: x* is Gaussian signal, Gaussian A, b=Ax*+eta,
%
% where eta~N(0,sigma^2).
% 
% FAL can solve problems with sigma>0; but it is optimized for sigma=0,
% i.e. Ax*=b. In the following example, by setting SNR(b)=infty
% (signal-to-noise ratio of b) we solve the basis pursuit problem 
%  min |x|_1 s.t. Ax=b

data = 0;
N = 64^2;
K = ceil(N/4);
T = ceil(K/10);
opts.tol=1e-8;

S = inf; %SNR(b)= S dB. If S=inf, then sigma=0 and b=Ax*
sigma = sqrt(T/(10^(S/10)));

seed = 601;
randn('state',seed); rand('state',seed);
addpath(genpath(pwd))
[A, b, xopt] = create_data(data,N,K,T,100); %if data=0, then x* has 100dB dynamic range
b = b+sigma*randn(K,1);

opts.sigma = sigma;
if sigma == 0
    opts.stop =1;
else
    opts.stop =2;
end

if data == 0
    opts.scale = false; %when A is partial DCT L=1, no need to scale
else
    % When A is Gaussian, to skip scaling an estimate of sigma_max(A) can be used.
    % opts.kappa = (1+sqrt(K/N))*sqrt(N);     
    opts.scale = true; %when rows of A are not orthogonal, scale A so that L=1
end
opts.xopt = xopt;
opts.disp = 1;
opts.record = false;
[x,out]=fal(N,A,b,opts);