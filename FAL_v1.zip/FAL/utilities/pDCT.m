function y=pDCT(x,mode,OMEGA,N)
if mode==1
    y = dct(x);
    y = y(OMEGA);
elseif mode==2
    K = size(x,1);
    y = zeros(N,1);
    y(OMEGA)=x(1:K);
    y = idct(y);
else
    error('mode should be 1 or 2');
end