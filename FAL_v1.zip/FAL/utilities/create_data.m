function [A, b, xopt]=create_data(data,N,K,T,DB)
if data == 0
    % x* is random signal with DB dynamic range, partial DCT A and  b=Ax*  
    xopt = zeros(N,1);
    q = randperm(N);
    q = q(1:T);
    valx = DB/20*rand(T,1);
    valx = valx - min(valx);
    valx = valx/max(valx)*DB/20;
    xopt(q) = 10.^valx.*sign(randn(T,1));
    display(['|x*|_1 = ', num2str(norm(xopt,1))])
    % measurement matrix
    disp('Creating measurment matrix...');
    OMEGA = randperm(N);
    OMEGA = OMEGA(1:K);
    OMEGA = sort(OMEGA);
    disp('Done.');
    %partial DCT tranform
    A = @(x,mode) pDCT(x,mode,OMEGA,N);
    % observations
    b = A(xopt,1);
elseif data == 1
    % x* is Gaussian signal, Gaussian A, b=Ax* 
    A = randn(K,N);
    p = randperm(N);
    xopt = zeros(N,1);
    xopt(p(1:T)) = randn(T,1);
    b = A*xopt;
end