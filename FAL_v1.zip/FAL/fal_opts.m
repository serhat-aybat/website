function opts = fal_opts(opts)

% Options for First-order Augmented Lagrangian (FAL) algorithm
%
% If opts left empty, opts will be returned containing the default
% options for fal.m.  
%
% Alternatively, if opts is passed with some fields already defined, those
% fields will be checked for errors, and the remaining fields will be added
% and initialized to their default values. 

% In this file 
% - xp represents the previous iterate.
% - x* represents the original signal
% - f=|.|_1 and avg(f) is moving average of 5 previous f(.) values
%
% Table of Options.  ** indicates default value.
%
% FIELD   OPTIONAL  DESCRIPTION
% .sigma    YES     Standard deviation of noisy measurements, i.e. b=Ax*+sigma*e,
%                   where each entry of e is standard Gaussian. 
% .x0       YES     Initial value of x.  If not defined, x will be
%                   initialized according to .init.
% .init     YES     If .x0 is not defined, .init specifies how x is to be initialized.                    
%                   0 -> zeros(n,1)
%                ** 1 -> x = Atb **
% .lambda0  YES     Initial value of lambda.  If not defined, lambda will be
%                   initialized to 0.99*norm(Atb,inf).                 
% .xopt     YES     Original signal x*.  If passed, fal will output some
%                   optimality and feasibilty statistics in out.stats.                   
% .stop     NO      Sopping criterion. FAL stops when
%                   0-> norm(x-x*,inf)< tol
%                ** 1-> norm(x-xp,inf)< tol ** (default when sigma=0)
%                ** 2-> norm(x-xp)/norm(xp)<1e-3*sigma ** (default when sigma>0, others cannot be used)
%                   3-> f/avg(f)< tol
%                   4-> norm(x-xp)/norm(xp)<tol
% .tol      NO      Tolerance on the chosen stopping criterion.
% .mxitr    NO      Maximum number of inner iterations.
%                ** 1000 **
% .kappa    YES     Is ratio of sigma_max(A)/sigma_min(A).
% .scale    NO      If true, fal will calculate sigma_max(A) and scale
%                   lambda0, A and b appropriately if it is not equal to 1.
%                ** true **
% .disp     YES     FAL display some run statistics:
%                ** 0-> no statistics **
%                   1-> statistics per FAL iteration
%                   2-> statistics per inner iteration
% .record   YES     If true, then FAL records ||x||_1, ||Ax-b||_2 and
%                   ||x-x*||_2/||x*||_2 values of each FAL iteration.
%                ** false **
% 
% Written by Necdet Serhat Aybat, Penn State University
%
% Last modified 14 June 2011.
if isfield(opts,'sigma')
    if opts.sigma<0
        error('opts.sigma should be non-negative!')
    end
else
    opts.sigma = 0;
end

if isfield(opts,'x0')
    if ~isvector(opts.x0) || ~min(isfinite(opts.x0))
        error('If used, opts.x0 should be an n x 1 vector of finite numbers.');
    end
elseif isfield(opts,'init')
    if ~isinInterval(opts.init,0,1,true) || opts.init ~= floor(opts.init)
        error('opts.init must be an integer either 0 or 1.');
    end
else
    opts.init = 1; 
end

if isfield(opts,'lambda0')
    if isinInterval(opts.lambda0,0,Inf,false)
        error('If used, opts.lambda0 must be a positive scalar.');
    end
end

if isfield(opts,'xopt')
     if ~isvector(opts.xopt) || ~min(isfinite(opts.xopt))
        error('If passed, opts.xopt should be an n x 1 vector of finite numbers.');
     end
else
    opts.xopt=[];
end

if isfield(opts,'stop')|| opts.init ~= floor(opts.stop)
    if ~isinInterval(opts.stop,0,3,true)
        error('opts.stop is the stopping criterion type.  Should be 0,1,2 or 3.');
    end
    if opts.stop == 0 && isempty(opts.xopt)
        error('if opts.stop=0, then ots.xopt should be supplied.');
    end
    if opts.sigma>0 && opts.stop~=2
        error('Only opts.stop=2 is allowed when opts.sigma>0')
    end
    if opts.stop==2 && opts.sigma==0
        error('opts.stop=2 is allowed only when opts.sigma>0')
    end
else
    if opts.sigma>0
        disp('Since opts.sigma>0, opts.stop=2 is the only allowed option.');
        opts.stop = 2;
    else
        disp('By default, opts.stop=1.');
        opts.stop = 1;
    end
end

if opts.sigma>0
        opts.tol=1e-3;
        disp(' ')
        disp('********************************************************')
        disp('b=Ax*+eta and eta~N(0,sigma^2)')
        disp(['sigma>0 --> Stopping Condition: norm(x-xp)/norm(xp)<',num2str(opts.tol),'*sigma'])
        disp('********************************************************')
        disp(' ')
end
if isfield(opts,'tol')
    if ~isinInterval(opts.tol,0,Inf,false)
        if opts.stop<=1
            error('opts.tol is a tolerance on the absolute error of x. Should be in (0,Inf).');
        elseif opts.stop==4
            error('opts.tol is a tolerance on the relative error of x. Should be in (0,1).');
        elseif opts.stop==3
            error('opts.tol is a tolerance on the relative change in |x|_1. Should be in (0,1).');
        else
            error('opts.tol is a tolerance on the stopping criterion and should be set correctly.');
        end
    end
else
    error('opts.tol is not optional. Please set the tolerance for the stopping criterion.');
end
    
if isfield(opts,'mxitr')
    if ~isinInterval(opts.mxitr,0,Inf,false) || opts.mxitr ~= floor(opts.mxitr)
        error('opts.mxitr should be a positive integer.');
    end
else
    opts.mxitr = 1000;
end

if isfield(opts,'kappa')
    if opts.kappa < 1
        error('opts.kappa is a condition number and so should be >= 1.');
    end
else
    opts.kappa = 0;
end

if isfield(opts,'scale')
    if ~islogical(opts.scale)
        error('opts.scale should be true or false.');
    elseif opts.kappa>0
        disp('opts.kappa is entered, scaling will be omitted.')
        opts.scale = false;
    end
else
    if opts.kappa>0
        disp('opts.kappa is entered, scaling will be omitted.')
        opts.scale = false;
    else
        opts.scale = true;
    end
end

if isfield(opts,'disp')
    if ~isinInterval(opts.disp,0,2,true)
        error('opts.disp can be 0,1 or 2.');
    end
else
    opts.disp = 0;
end

if isfield(opts,'record')
    if ~islogical(opts.record)
        error('opts.record should be true or false.');
    elseif isempty(opts.xopt)
        error('to record statistics opts.xopt should be provided.');
    end
else
    opts.record = false;
end
return