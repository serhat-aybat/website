function [x,out]=fal(N,A,b,opts)

% First-order Augmented Lagrangian (FAL) algorithm for basis pursuit
%
% Solves
%
%   min ||x||_1 s.t. Ax=b
%
% Inputs
% 
% A - an explicit m x n matrix, or a function handle that implements 
%     A*x and A'*x.  If the latter, this function must have the form
%
%     function y = name(x,mode)
%
%     where if mode == 1 then x is n x 1 and y = A*x, and if mode == 2 then 
%     x is m x 1 and y = A'*x.
%
% b - an m x 1 vector.
%
%
% fal_opts.m describes the available options.  If opts is passed as empty,
% fal_opts will be called to obtain the default values.
%
% Outputs
%
%   x           - x at last iteration
%   out.lambda  - vector of lambda values for each outer iteration
%   out.l1      - vector of ||x||_1
%   out.res     - vector of residual norm values: ||Ax-b||_2
%   out.rel     - if opts.xs exists, is vector of norm(x - xs)/norm(xs).
%                 starts with 0th iteration.
%   out.oitr    - number of FAL iterations to convergence
%   out.itr     - number of inner iterations to convergence (or Inf if reach mxitr)
%   out.itrs    - vector of number of inner iterations completed during each
%                 outer iteration
%   out.nmat    - number of matrix multiplications with A and A'
%
% Written by Necdet Serhat Aybat, Penn State University
%
% Last modified 14 June 2011.
%**************************************************************************
    addpath(genpath('./'));
    global L c0 coef_tau nz nrm_xopt
    global outer_iter_counter inner_iter_counter total_operation_counter total_time optimality_flag
    tic
    % Algorithm Parameters- One can tune these parameters, performance of
    % FAL cricially depends on these parameters. For example, on hard problems, 
    % e.g. Caltech Data set use
    % c0 = 0.9; coef_tau = 0.8; coef_lambda = 0.8; stepsize = 1.9;
    
    c0 = 0.9; coef_tau = 0.4; coef_lambda = 0.4; stepsize = 2;
       
    % get or check opts
    opts = fal_opts(opts);

    % check scaling
    if opts.scale || opts.kappa>0
        disp('FAL is checking the scaling of your problem because opts.scale = true or opts.kappa is entered.');
        if opts.sigma>0
            [A,b,scale_constant] = scaleProblem(N,A,b,opts.kappa,0); 
            opts.sigma=opts.sigma/scale_constant;
        else
            [A,b] = scaleProblem(N,A,b,opts.kappa,0);
            % try also [A,b,scale_constant] = scaleProblem(N,A,b,opts.kappa,1);
            % this option requires QR decomposition of A, but cuts down
            % iteration count by half.
        end
    end

    % unify implementation of A
    if isa(A,'function_handle')
        A = A_operator(@(x) A(x,1), @(x) A(x,2));
    end

    % initialize x0, lambda, beta
    [x0,lambda,beta,Ax,out] = fal_init(A,b,N,opts);
    
    %nz is the number of nonzeros in the last iterate x_k
    L = 1; opt_lambda=1e-14; tau = inf; nz=[];
    outer_iter_counter = 0; inner_iter_counter = 0; total_operation_counter = 1; total_time = 0; optimality_flag = 1;
    dual_vector = 0;
    
    out.lambda = lambda;
    if ~isempty(opts.xopt)
        nrm_xopt=norm(opts.xopt,2);
    end
    if opts.record == true
        out.l1 = norm(x0,1);
        out.res = norm(Ax-b);
        if ~isempty(opts.xopt)
            out.rel = norm(x0 - opts.xopt)/nrm_xopt;
        end
    end

    while(optimality_flag)
        %display(['lambda=',num2str(lambda)])
        outer_iter_counter = outer_iter_counter + 1;

        b_prime = b+lambda*dual_vector;
        [x, tau, iter_counter, operation_counter] = algorithm_3(x0,A,b_prime,lambda,beta,tau,stepsize,Ax,N,b,opts);

        inner_iter_counter = inner_iter_counter + iter_counter;
        total_operation_counter = total_operation_counter + operation_counter;
        out.itrs = [out.itrs; iter_counter];

        if optimality_flag ~= 0
            if outer_iter_counter >=2
                nzr = nz(outer_iter_counter)/length(b);
                [coef_lambda, coef_tau, stepsize] = set_coefficients(nzr);
            end
            Ax = A*x;
            dual_vector = dual_vector - (Ax-b)/lambda;
            lambda = max(lambda*coef_lambda,opt_lambda);
            out.lambda = [out.lambda; lambda];
            x0 = x;
            
            if opts.record == true
                out.l1 = [out.l1; norm(x,1)];
                out.res = [out.res; norm(Ax-b)];
                if ~isempty(opts.xopt),  out.rel = [out.rel; norm(x - opts.xopt)/nrm_xopt]; end
            end
        end
    end
    if opts.record == true
        out.l1 = [out.l1; norm(x,1)];
        out.res = [out.res; norm(A*x-b)];
        if ~isempty(opts.xopt),  out.rel = [out.rel; norm(x - opts.xopt)/nrm_xopt]; end
    end
end % fpc

%--------------------------------------------------------------------------
% SUBFUNCTION FOR INITIALIZATION
%--------------------------------------------------------------------------
%
% OUTPUTS -----------------------------------------------------------------
% x       - initialized based on opts.x0 and opts.init.  if opts.x0 exists, 
%           x = opts.x0; otherwise, opts.init determines x:
%           0 - x = zeros(n,1)
%           1 - x = Atb
% lambda  - if opts.lambda0 exists, lambda=opts.lambda0; otherwise, set 
%           based on x = 0, lambda = 0.99*norm(Atb,inf)
%--------------------------------------------------------------------------

function [x0,lambda,beta,Ax,out] = fal_init(A,b,N,opts)

% calculate lambda0 A'*b
Atb = A'*b;

% initialize x0
if isfield(opts,'x0')
    x0 = opts.x0;
    if length(x0) ~= N, error('User supplied x0 is wrong size.'); end
else
    switch opts.init
        case 0, x0 = zeros(N,1);
        case 1, x0 = Atb;
    end
end

% initialize lambda and beta
if isfield(opts,'lambda0')
    lambda = opts.lambda0;
else
    lambda = 0.99*norm(Atb,inf); % initial guess = min energy
end
beta = norm(x0,1);

% check for 0 solution
if lambda >= norm(Atb,'inf'); 
    error('opt.lambda0 value is too big, choose a smaller value');
end
Ax=A*x0;
out.itrs=[];
out.l1 = [];
out.res = []; 
out.rel=[];
end % fal_init
        
% Last modified 10 January 2008.