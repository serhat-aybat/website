function [X,s]=XS_subproblem(Q,coef,d,omega_bar)
% omega_bar is subset [1,n^2] denoting the one dimensional index set of observed
% entries of nxn-matrix D, not inclusing the diagonal of ones; and
% d=D(omega_bar).
n=size(Q,1);
s_bar = d-Q(omega_bar);
s=min(d,max(-1,sign(s_bar).*max(abs(s_bar)-coef, 0)));
X=max(Q,0);
for i=1:n
    X(i,i)=1;
end
X(omega_bar)=d-s;