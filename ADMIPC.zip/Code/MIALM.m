function [L, S, iter] = MIALM(d, omega_bar, n, rho, tol, maxIter)

% D - unknown nxn node-node incidence matrix s.t. diag(D)=1
%
% omega_bar - subset of [1,n^2] denoting the one dimensional index set of observed
% entries of nxn-matrix D, not inclusing the diagonal of ones;
%
% d - vector of observations/data d=D(omega_bar) (required input)
%
% rho - weight on sparse error term in the cost function
%
% tol - relative error tolerance for stopping criterion.
%     - DEFAULT 5e-4 if omitted or -1.
%
% maxIter - maximum number of iterations
%         - DEFAULT 1000, if omitted or -1.
% 
% Initialize L,X,s,Y
% while ~converged 
%   minimize (inexactly, update S and L only once)
%     L(L,X,s,Y) = |L|_*+rho*|Pi(S)|_1 + <Y,L+S-Pi(D)> + mu/2*|L+S-Pi(D)|_F^2 
%   Y = Y + mu * (L+S-Pi(D));
%   mu = kappa * mu;
% end

addpath PROPACK_SVT;

if nargin < 4
    rho = 1 / sqrt(n);
end

if nargin < 5
    tol = 5e-4;
elseif tol == -1
    tol = 5e-4;
end

if nargin < 6
    maxIter = 1000;
elseif maxIter == -1
    maxIter = 1000;
end

% initialize
Y = eye(n);
diag_ind = find(Y == 1);
Y(omega_bar) = d;
norm_two = lansvd(Y, 1, 'L');
norm_inf = norm( Y(:), inf) / rho;
dual_norm = max(norm_two, norm_inf);
D = Y;
Y = Y / dual_norm;
omega_bar = [omega_bar; diag_ind];
L = zeros(n);

mu = 1.25/norm_two; % this one can be tuned
mu_bar = mu * 1e7;
kappa = 1.2;        % this one can be tuned
d_norm = sqrt(norm(d)^2+n);

iter = 0;
total_svd = 0;
converged = false;
stopCriterion = 1;
sv = 10;
while ~converged       
    iter = iter + 1;
    
    S = D-L-(1/mu)*Y;
    S(omega_bar) = sign(S(omega_bar)).*max(abs(S(omega_bar))-rho/mu,0);
    
    [U, Sigma, V] = lansvd(D-S-(1/mu)*Y, sv, 'L');
    diagS = diag(Sigma);
    svp = length(find(diagS > 1/mu));
    if svp < sv
        sv = min(svp + 1, n);
    else
        sv = min(svp + round(0.05*n), n);
    end
    Lp = L;
    L = U(:, 1:svp) * diag(diagS(1:svp) - 1/mu) * V(:, 1:svp)';
    total_svd = total_svd + 1;
    
    Z = L+S-D;
    Y = Y + mu*Z;

    %% stop Criterion    
    stopCriterion_p = norm(Z, 'fro')/max([norm(L,'fro'),norm(S,'fro'),d_norm]);
    stopCriterion_d = mu*norm(L-Lp,'fro')/(d_norm*norm(Y,'fro'));
    
    if (stopCriterion_p < tol)&&(stopCriterion_d < tol)
        converged = true;
    end
    
    mu = min(mu*kappa, mu_bar);
    
    if mod(total_svd, 100) == 0
        disp(['#svd ' num2str(total_svd) ' r(L) ' num2str(rank(L))...
            ' |S|_0 ' num2str(length(find(abs(S)>0)))...
            ' p-stopCriterion ' num2str(stopCriterion_p)...
            ' d-stopCriterion ' num2str(stopCriterion_d)]);
    end    
    
    if ~converged && iter >= maxIter
        disp('Maximum iterations reached') ;
        converged = 1 ;       
    end
end
