function [L, X, s, iter] = ADMIPC_v2(d, omega_bar, n, svd_flag, rho, tol, maxIter)

% D - unknown nxn node-node incidence matrix s.t. diag(D)=1
%
% omega_bar - subset of [1,n^2] denoting the one dimensional index set of observed
% entries of nxn-matrix D, not inclusing the diagonal of ones;
%
% d - vector of observations/data d=D(omega_bar) (required input)
%
% rho - weight on sparse error term in the cost function
%
% tol - relative error tolerance for stopping criterion.
%     - DEFAULT 5e-4 if omitted or -1.
%
% maxIter - maximum number of iterations
%         - DEFAULT 1000, if omitted or -1.
% 
% Initialize L,X,s,Y
% while ~converged 
%   minimize (inexactly, update (X,s) and L only once)
%     L(L,X,s,Y) = Tr(L)+rho*|S|_1 + <Y,X-L> + mu/2*|X-L|_F^2
%   s.t. L pos def, and (X,s) \in phi (see the def. of phi in the paper) 
%   Y = Y + mu * (X-L);
%   mu = kappa * mu;
% end

global r
addpath PROPACK_SVT;
if svd_flag == 2
    OPTIONS.increaseK = 10;
end

if nargin < 4
    rho = 1 / sqrt(n);
end

if nargin < 5
    tol = 5e-4;
elseif tol == -1
    tol = 5e-4;
end

if nargin < 6
    maxIter = 1000;
elseif maxIter == -1
    maxIter = 1000;
end

% initialize
Y = eye(n);
Y(omega_bar) = d;
norm_two = lansvd(Y, 1, 'L');
norm_inf = norm( Y(:), inf) / rho;
dual_norm = max(norm_two, norm_inf);
Y = Y / dual_norm;
L = zeros(n);

mu = 1.25/norm_two; % this one can be tuned
mu_bar = mu * 1e7;
kappa = 1.2;        % this one can be tuned
d_norm = sqrt(norm(d)^2+n);

iter = 0;
total_svd = 0;
converged = false;
sv = 10;
while ~converged       
    iter = iter + 1;
    
    [X,s] = XS_subproblem(L-(1/mu)*Y,rho/mu,d,omega_bar);
    
    if svd_flag == 2
        OPTIONS.minSingValue = 1/mu;
        sv = round(0.95*sv);
        [U,Sigma,V] = lansvd(X+(1/mu)*Y, sv, 'T', OPTIONS);
        diagS = diag(Sigma);
        sv = length(find(diagS > 1/mu));
    else
        if svd_flag == 1
            sv = ceil(r*1.2);
        end
        [U, Sigma, V] = lansvd(X+(1/mu)*Y, sv, 'L');
        diagS = diag(Sigma);
    end
    
    Lp = L;
    L = zeros(n);
    max_sigma = -inf;
    for i=1:sv
        if U(:,i)'*V(:,i) < 0
            diagS(i) = 0;
        else
            if diagS(i) > 1/mu
                diagS(i) = diagS(i)-1/mu;
                L = L+diagS(i)*U(:,i)*V(:,i)';
                if diagS(i) > max_sigma
                    max_sigma = diagS(i);
                end
            end
        end
    end
    
    if svd_flag == 2
        sv = length(find(diagS > 0));
    else
        svp = length(find(diagS/max_sigma>1/n));
        if svp < sv
            sv = min(svp + 1, n);
        else
            sv = min(round(1.1*svp), n);
        end
    end

    total_svd = total_svd + 1;
    
    Z = X-L;    
    Y = Y + mu*Z;

    %% stop Criterion    
    stopCriterion_p = norm(Z, 'fro')/max(norm(L,'fro'),norm(X,'fro'));
    stopCriterion_d = mu*norm(L-Lp,'fro')/(d_norm*norm(Y,'fro'));
    
    if (stopCriterion_p < tol)&&(stopCriterion_d < tol)
        converged = true;
    end
    
    mu = min(mu*kappa, mu_bar);
    
    if mod( total_svd, 100) == 0
        disp(['#svd ' num2str(total_svd) ' r(L) ' num2str(rank(L))...
            ' |S|_0 ' num2str(length(find(abs(s)>0)))...
            ' p-stopCriterion ' num2str(stopCriterion_p)...
            ' d-stopCriterion ' num2str(stopCriterion_d)]);
    end    
    
    if ~converged && iter >= maxIter
        disp('Maximum iterations reached') ;
        converged = 1 ;       
    end
end
