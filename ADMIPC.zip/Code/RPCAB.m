function [L, S, iter_array] = RPCAB(d, omega_bar, n, tol, maxIter)
S=[];
iter_array = [];
rho = 1/sqrt(n);
iter = 1;
converged = false;

while ~converged
    [L, ~, iter_ialm] = MIALM(d, omega_bar, n, rho, 5e-4, 1000);
    iter_array = [iter_array, iter_ialm];
    stop_crit = abs(trace(L)-n)/n;
    disp(['|Tr(L)-n|/n = ',num2str(stop_crit)])
    disp('___________________________________')
    if (stop_crit < tol) || (iter > maxIter)
        converged = true;
    elseif trace(L)>n
        rho = rho/2;
    elseif trace(L)<n
        rho = rho*2;
    end
    iter = iter+1;
end