clc
clear all
rng(13)
experiment_number = 1;
alpha = 0.9; n = 500; p0 = 0.9;
global r
r = ceil(0.05*n);
c_size = zeros(r,1);

for i=1:r
    if alpha == 1
        c_size(i) = round(n/r);
    else
        c_size(i)= round(n*alpha^(i-1)*(1-alpha)/(1-alpha^r));
    end
end

c_size = c_size(find(c_size>0));
r = size(c_size,1);
n_org = n;
if n ~= sum(c_size)
    n = sum(c_size);
end
disp(['n = ',num2str(n)])
disp(['Cluster Sizes : ',num2str(c_size')])

index_interval = cumsum(c_size);
index_interval = [0; index_interval];

off_size = n^2;
C = cell(r,1);
for i=1:r
    off_size = off_size - c_size(i)^2;
    C{i}=[index_interval(i)+1:index_interval(i+1)]';
end
up_diag_ind = [];
for i=1:n-1
    up_diag_ind = [up_diag_ind, [i*n+1: i*n+i]];
end
up_diag_ind = up_diag_ind';

results_admipc = zeros(7,experiment_number);
results_mialm = zeros(7,experiment_number);
results_rpcab = zeros(8,experiment_number);

for k=1:experiment_number
    disp(' ')
    disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
    disp(['Experiment #',num2str(k)])
    disp('~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~')
    disp(' ')
    s = round(0.05*(n^2-n)/2);
    rand_ind = randperm((n^2-n)/2,s);
    D_perturb = zeros(n);
    D_perturb(up_diag_ind(rand_ind)) = 1;
    D_perturb = D_perturb + D_perturb';
    D = zeros(n);
    for i=1:r
        D(C{i},C{i})=1;
    end
    c_ind = find(D == 1);
    s_ind = find(D_perturb == 1);
    edge_ind = setxor(c_ind,s_ind);
    clear D_perturb
    D = zeros(n);
    D(edge_ind) = 1;
    
    if p0<1
        obs_number = round(p0*(n^2-n)/2);
        omega_bar = randperm((n^2-n)/2,obs_number);
    elseif p0==1
        omega_bar = (1:(n^2-n)/2);
    end
    D_obs = zeros(n);
    D_obs(up_diag_ind(omega_bar)) = 1;
    D_obs = D_obs + D_obs';
    omega_bar = find(D_obs == 1);
    d = D(omega_bar);
    clear D D_obs
    %%
    tic
    % tol = 2e-4; recovers small clusters well
    [L, ~, ~, iter] = ADMIPC_v2(d, omega_bar, n, 0, 1/sqrt(n), 5e-4, 1000);
    cpu_admipc = toc;
    stat_admipc = report_stat(L, n, c_size, off_size, C);
    disp('ADMIPC RESULTS:')
    disp([stat_admipc;cpu_admipc])
    disp('***********************************')
    results_admipc(1:5,k) = stat_admipc;
    results_admipc(6,k) = cpu_admipc;
    results_admipc(7,k) = iter;
    clear L
    %%
    tic
    [L_mialm, ~, iter] = MIALM(d, omega_bar, n, 1/sqrt(n), 5e-4, 1000);
    cpu_mialm = toc;
    stat_mialm = report_stat(L_mialm, n, c_size, off_size, C);
    disp('MIALM RESULTS:')
    disp([stat_mialm;cpu_mialm])
    disp('***********************************')
    results_mialm(1:5,k) = stat_mialm;
    results_mialm(6,k) = cpu_mialm;
    results_mialm(7,k) = sum(iter);
    clear L_mialm
    %%
    tic
    [L_rpcab, ~, iter_array] = RPCAB(d, omega_bar, n, 1e-2, 100);
    cpu_rpcab = toc;
    stat_rpcab = report_stat(L_rpcab, n, c_size, off_size, C);
    disp('RPCAB RESULTS:')
    disp([stat_rpcab;cpu_rpcab])
    disp('***********************************')
    results_rpcab(1:5,k) = stat_rpcab;
    results_rpcab(6,k) = cpu_rpcab;
    results_rpcab(7,k) = sum(iter_array);
    results_rpcab(8,k) = size(iter_array,2);
    clear L_rpcab
end
%%
mean_results_admipc = mean(results_admipc,2)';
mean_results_mialm = mean(results_mialm,2)';
mean_results_rpcab = mean(results_rpcab,2)';
save(['results_n',num2str(n_org),'_a',num2str(alpha),'_p',num2str(p0),'.mat'],'mean_results_admipc','mean_results_mialm','mean_results_rpcab', ...
    'results_admipc','results_mialm','results_rpcab')
clear all