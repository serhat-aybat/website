function [stat] = report_stat(L, n, c_size, off_size, C)
r = size(c_size,1);
stat = zeros(5,1);
cluster_inner_error = zeros(r,1);
cluster_outer_error = zeros(r,1); 
for i=1:r
    cluster_inner_error(i) = norm(L(C{i},C{i})-ones(c_size(i)),'fro')/c_size(i);
    L_outer = L(C{i},:);
    L_outer(:,C{i}) = zeros(c_size(i));
    cluster_outer_error(i) = norm(L_outer,'fro');
    stat(4) = stat(4)+cluster_outer_error(i)^2;
    cluster_outer_error(i) = cluster_outer_error(i)/sqrt(c_size(i)*(n-c_size(i)));
    if (cluster_inner_error(i)<=0.4)&&(cluster_outer_error(i)<=0.1)
        stat(5) = stat(5)+1;
    end
end

stat(1) = max(cluster_inner_error);
stat(2) = min(cluster_inner_error);
stat(3) = mean(cluster_inner_error);
stat(4) = sqrt(stat(4)/off_size);
stat(5) = stat(5)/r;